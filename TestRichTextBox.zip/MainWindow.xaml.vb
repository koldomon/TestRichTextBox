﻿Imports System.IO
Imports System.Windows.Markup

Class TestRichTextBox
#Region "Debug"
    Private Sub SetRichTextBoxCarret(thisRTB As RichTextBox, thisTP As TextPointer, Optional additionalOffset As Int32 = 0)
        Dim myOut As New Text.StringBuilder

        Dim myDirection = If(CBool(thisTP.GetPointerContext(LogicalDirection.Forward) = TextPointerContext.Text), LogicalDirection.Forward, LogicalDirection.Backward)
        myOut.AppendLine(String.Format("{0,-40}{1}", "myDirection:", myDirection))

        Dim myDestinationPosition = thisTP.GetPositionAtOffset(additionalOffset, myDirection)
        myOut.AppendLine(String.Format("{0,-40}{1}", "myDestinationPosition LogicalDirection:", myDestinationPosition.LogicalDirection))
        myOut.AppendLine(String.Format("{0,-40}{1}", "myDestinationPosition Offset:", thisRTB.Document.ContentStart.GetOffsetToPosition(myDestinationPosition)))
        myOut.AppendLine("")

        myOut.AppendLine(String.Format("{0,-40}{1}", "TextPointer LogicalDirection:", thisTP.LogicalDirection))
        myOut.AppendLine(String.Format("{0,-40}{1}", "TextPointer Offset:", thisRTB.Document.ContentStart.GetOffsetToPosition(thisTP)))
        myOut.AppendLine(String.Format("{0,-40}""{1}""", "TextPointer Text:", thisTP.GetTextInRun(myDirection)))
        myOut.AppendLine(String.Format("{0,-40}{1}", "TextPointer ContextBackward:", thisTP.GetPointerContext(LogicalDirection.Backward)))
        myOut.AppendLine(String.Format("{0,-40}{1}", "TextPointer ContextForward:", thisTP.GetPointerContext(LogicalDirection.Forward)))
        myOut.AppendLine("")
        myOut.AppendLine(String.Format("{0,-40}{1}", "Caret LogicalDirection (before set):", thisRTB.CaretPosition.LogicalDirection))
        myOut.AppendLine(String.Format("{0,-40}{1}", "Caret Offset (before set):", thisRTB.Document.ContentStart.GetOffsetToPosition(thisRTB.CaretPosition)))
        myOut.AppendLine(String.Format("{0,-40}""{1}""", "Caret Text (before set):", thisRTB.CaretPosition.GetTextInRun(myDirection)))
        myOut.AppendLine(String.Format("{0,-40}{1}", "Caret Context Backward (before set):", thisRTB.CaretPosition.GetPointerContext(LogicalDirection.Backward)))
        myOut.AppendLine(String.Format("{0,-40}{1}", "Caret Context Forward (before set):", thisRTB.CaretPosition.GetPointerContext(LogicalDirection.Forward)))
        myOut.AppendLine("")

        thisRTB.CaretPosition = myDestinationPosition

        myOut.AppendLine(String.Format("{0,-40}{1}", "Caret LogicalDirection (after set):", thisRTB.CaretPosition.LogicalDirection))
        myOut.AppendLine(String.Format("{0,-40}{1}", "Caret Offset (after set):", thisRTB.Document.ContentStart.GetOffsetToPosition(thisRTB.CaretPosition)))
        myOut.AppendLine(String.Format("{0,-40}""{1}""", "Caret Text (after set):", thisRTB.CaretPosition.GetTextInRun(myDirection)))
        myOut.AppendLine(String.Format("{0,-40}{1}", "Caret Context Backward (after set):", thisRTB.CaretPosition.GetPointerContext(LogicalDirection.Backward)))
        myOut.AppendLine(String.Format("{0,-40}{1}", "Caret Context Forward (after set):", thisRTB.CaretPosition.GetPointerContext(LogicalDirection.Forward)))

        txtDebugOut.Text = (myOut.ToString)
    End Sub
#End Region
    Private myCurrentPosition As TextPointer


    Private Sub LoadOK_Click(sender As Object, e As RoutedEventArgs)
        Dim myDoc = LoadXamlPackage(".\CriteriaTree_OK.xaml")
        If (myDoc IsNot Nothing) Then
            myCurrentPosition = Nothing
            Me.rtbTest.Document = myDoc
        End If
    End Sub
    Private Sub LoadNotOK_Click(sender As Object, e As RoutedEventArgs)
        Dim myDoc = LoadXamlPackage(".\CriteriaTree_NotOK.xaml")
        If (myDoc IsNot Nothing) Then
            myCurrentPosition = Nothing
            Me.rtbTest.Document = myDoc
        End If
    End Sub

    Private Shared Function LoadXamlPackage(f As String) As FlowDocument
        If (Not IO.File.Exists(f)) Then Return Nothing

        Dim myReturn As FlowDocument = Nothing

        Using myReader = File.OpenRead(f)
            myReturn = TryCast(XamlReader.Load(myReader), FlowDocument)
        End Using

        Return myReturn
    End Function

    Private Sub Set_CaretPosition(sender As Object, e As RoutedEventArgs)
        Dim myRTB = Me.rtbTest
        Dim myParagraph = DirectCast(myRTB.Document.Blocks(0), Paragraph)
        Dim mySpan = DirectCast(myParagraph.Inlines(0), Span)
        Dim myRun = DirectCast(mySpan.Inlines(1), Run)
        myRTB.Focus()
        SetRichTextBoxCarret(myRTB, myRun.ContentStart)
    End Sub

    Private Sub Debug_CaretPosition(sender As Object, e As RoutedEventArgs)
        Dim myRTB = Me.rtbTest
        myRTB.Focus()

        myCurrentPosition = myRTB.CaretPosition

        SetRichTextBoxCarret(myRTB, myRTB.CaretPosition)
    End Sub


    Private Sub CaretPosition_Increase(sender As Object, e As RoutedEventArgs)
        Dim myRTB = Me.rtbTest
        myRTB.Focus()

        If (myCurrentPosition Is Nothing) Then myCurrentPosition = myRTB.CaretPosition
        myCurrentPosition = myCurrentPosition.GetPositionAtOffset(1)

        SetRichTextBoxCarret(myRTB, myCurrentPosition)
    End Sub

    Private Sub CaretPosition_Decrease(sender As Object, e As RoutedEventArgs)
        Dim myRTB = Me.rtbTest
        myRTB.Focus()

        If (myCurrentPosition Is Nothing) Then myCurrentPosition = myRTB.CaretPosition
        myCurrentPosition = myCurrentPosition.GetPositionAtOffset(-1)

        SetRichTextBoxCarret(myRTB, myCurrentPosition)
    End Sub
End Class
